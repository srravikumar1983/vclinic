﻿

let regx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
$("#email").blur(function () {
    let email = this.value;
    let success = regx.test(email);
    if (!success && email.trim().length > 0) {
        $("#invalidemail").removeClass("hide");
        this.focus();
    }
    else {
        $("#invalidemail").addClass("hide");
    }

});
$("#phoneno").blur(function () {
    if (isNaN(this.value)) {
        $("#invalidphone").removeClass("hide");
        this.focus();
    }
    else {
        $("#invalidphone").addClass("hide");
    }
});

$("#membershipselect").change(function () {
    if (this.value === null) {
        $("#invalidmembership").removeClass("hide");
    }
    else {
        $("#invalidmembership").addClass("hide");
    }
});

$("#btnbook").click(function () {
    let selection = $("#membershipselect");
    if ($(selection).val() === null) {
        $("#invalidmembership").removeClass("hide");
        return false;
    }
    else {
        $("#invalidmembership").addClass("hide");
    }
    return true;
});


$(document).ready(function () {
    $(".planDetails").html($("#planTemaplate").html());
    $("#appointmentdate").datetimepicker({
        format: 'DD/MM/YYYY HH:mm',
        minDate: new Date()
    });
});

function SaveBookings() {
    alett("Not yet implemented.")
}



